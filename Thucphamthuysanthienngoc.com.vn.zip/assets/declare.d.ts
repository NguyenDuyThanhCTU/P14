declare module "uuid";
declare module "react-animate-on-scroll";
