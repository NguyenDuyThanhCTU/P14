import PageGioiThieu from "@components/client/Page/PageGioiThieu";
import React from "react";

const IntroducePage = () => {
  return (
    <div>
      <PageGioiThieu />
    </div>
  );
};

export default IntroducePage;
