import Homepage from "@components/client/Home/Homepage";
import React from "react";

const page = () => {
  return (
    <div className="text-red-500">
      <Homepage />
    </div>
  );
};

export default page;
