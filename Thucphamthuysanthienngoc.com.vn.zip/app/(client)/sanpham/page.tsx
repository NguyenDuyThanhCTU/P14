import PageSanPham from "@components/client/Page/PageSanPham";
import React from "react";

const ProductPage = () => {
  return (
    <div>
      <PageSanPham />
    </div>
  );
};

export default ProductPage;
