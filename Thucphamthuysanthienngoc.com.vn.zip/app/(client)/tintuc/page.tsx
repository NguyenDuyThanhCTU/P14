import PageTinTuc from "@components/client/Page/PageTinTuc";
import React from "react";

const NewsPage = () => {
  return (
    <div>
      <PageTinTuc />
    </div>
  );
};

export default NewsPage;
