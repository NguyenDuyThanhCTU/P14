import PageTinTuc from "@components/client/Page/PageTinTuc";

import React from "react";

const NewsPage = async () => {
  return (
    <>
      <PageTinTuc />
    </>
  );
};

export default NewsPage;
