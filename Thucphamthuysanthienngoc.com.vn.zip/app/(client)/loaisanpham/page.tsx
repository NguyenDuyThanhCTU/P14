import PageLoaiSanPham from "@components/client/Page/PageLoaiSanPham";
import React from "react";

const ProductTypePage = () => {
  return (
    <div>
      <PageLoaiSanPham />
    </div>
  );
};

export default ProductTypePage;
