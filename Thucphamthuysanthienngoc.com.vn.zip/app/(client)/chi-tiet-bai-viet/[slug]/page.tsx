import PageNewsDetail from "@components/client/Page/PageNewsDetail";

import React from "react";

const NewsDetailPage = async () => {
  return (
    <>
      <PageNewsDetail />
    </>
  );
};

export default NewsDetailPage;
