import ChiTietBaiViet from "@components/client/Page/ChiTietBaiViet";
import React from "react";

const PostDetail = () => {
  return (
    <div>
      <ChiTietBaiViet />
    </div>
  );
};

export default PostDetail;
