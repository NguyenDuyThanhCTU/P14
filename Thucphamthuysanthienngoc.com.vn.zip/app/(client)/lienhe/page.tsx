import PageLienHe from "@components/client/Page/PageLienHe";
import React from "react";

const ContactPage = () => {
  return (
    <div>
      <PageLienHe />
    </div>
  );
};

export default ContactPage;
