import PageSalesOff from "@components/client/Page/PageSalesOff";
import React from "react";

const page = () => {
  return (
    <div>
      <PageSalesOff />
    </div>
  );
};

export default page;
