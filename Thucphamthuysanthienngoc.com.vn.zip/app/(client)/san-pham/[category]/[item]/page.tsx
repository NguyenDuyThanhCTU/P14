import ChiTietSanPham from "@components/client/Page/ChiTietSanPham";
import React from "react";

const ProductDetail = () => {
  return (
    <div>
      <ChiTietSanPham />
    </div>
  );
};

export default ProductDetail;
