import ChiTietSanPham from "@components/client/Page/ChiTietSanPham";
import React from "react";

const ProductDetail1 = () => {
  return (
    <div>
      <ChiTietSanPham />
    </div>
  );
};

export default ProductDetail1;
