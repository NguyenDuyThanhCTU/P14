import PageTatCaSanPham from "@components/client/Page/PageTatCaSanPham";
import React from "react";

const AllProductPage = () => {
  return (
    <div>
      <PageTatCaSanPham />
    </div>
  );
};

export default AllProductPage;
