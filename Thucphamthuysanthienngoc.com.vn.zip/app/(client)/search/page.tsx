import PageSearch from "@components/client/Page/PageSearch";
import React from "react";

const SearchPage = () => {
  return (
    <div>
      <PageSearch />
    </div>
  );
};

export default SearchPage;
