import { Doitac } from "@components/client/Page/doitac";
import React from "react";

const page = () => {
  return (
    <div>
      <Doitac />
    </div>
  );
};

export default page;
